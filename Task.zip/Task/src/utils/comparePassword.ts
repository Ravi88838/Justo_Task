export const comparePassword = (str: string, str1: string) => {
  console.log(str, str1);
  return str === str1;
};
